<template>
  <footer class="footer">
    <div class="content has-text-centered">
      <p>
        <!-- 푸터 내용을 여기에 작성하세요 -->
        &copy; Copyright © 2024 CodingNest. All rights reserved.
      </p>
    </div>
  </footer>
</template>
  
  <script>
  export default {
    name: 'AppFooter'
  }
  </script>
  
  <style scoped>
  /* 필요한 스타일링을 여기에 추가합니다. */
  </style>