module.exports = {
    presets: [
      '@babel/preset-env'
    ],
    plugins: [
      '@babel/plugin-transform-private-methods',
      '@babel/plugin-proposal-private-methods'
    ]
  };
  